"""
alembic/env.py
==============
Configuracion del entorno de migraciones.

- La URL de la BD viene de Settings.database_url (mismo origen que la app).
- target_metadata apunta a Base para que --autogenerate compare el esquema
  real con los modelos SQLAlchemy.
- Se importan todos los modulos de modelos antes de referenciar Base.metadata
  para que Alembic vea todas las tablas registradas.
"""

from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from app.config import get_settings

# Importar todos los modelos para que esten registrados en Base.metadata
import app.models.user       # noqa: F401
import app.models.security   # noqa: F401
import app.models.price      # noqa: F401
import app.models.portfolio  # noqa: F401
from app.models.base import Base

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Sobreescribir la URL con la de Settings (ignora el valor de alembic.ini)
config.set_main_option("sqlalchemy.url", get_settings().database_url)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Genera SQL sin conectarse a la BD (util para revisar migraciones)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,  # necesario para ALTER TABLE en SQLite
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Aplica migraciones sobre una conexion real."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=True,  # necesario para ALTER TABLE en SQLite
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
