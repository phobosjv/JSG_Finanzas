import { useEffect, useRef, useState } from 'react'
import { api } from '../api/client'
import { useAuth } from '../context/AuthContext'
import { useAppConfig } from '../context/AppContext'

function fmt(dt) {
  if (!dt) return '—'
  return new Date(dt).toLocaleDateString('es-ES')
}

function fmtDatetime(dt) {
  if (!dt) return '—'
  return new Date(dt).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })
}

// ---------------------------------------------------------------------------
//  Badge de estado de usuario
// ---------------------------------------------------------------------------

function StatusBadge({ enabled }) {
  return (
    <span className="badge" style={{
      background: enabled ? '#1a3a2a' : '#3a1a1a',
      color: enabled ? 'var(--green)' : 'var(--red)',
    }}>
      {enabled ? 'Activo' : 'Inactivo'}
    </span>
  )
}

// ---------------------------------------------------------------------------
//  Modal: habilitar / deshabilitar usuario
// ---------------------------------------------------------------------------

function UserStatusModal({ user, onClose, onDone }) {
  const enabling = !user.is_enabled
  const [annotation, setAnnotation] = useState('')
  const [withExpiry, setWithExpiry] = useState(false)
  const [expiryDate, setExpiryDate] = useState('')
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setError(null)
    try {
      await api.patch(`/admin/users/${user.id}/status`, {
        enabled: enabling,
        annotation: annotation || null,
      })
      // Si se está habilitando y se ha marcado poner fecha de caducidad
      if (enabling && withExpiry && expiryDate) {
        await api.patch(`/admin/users/${user.id}/expiry`, { expires_at: expiryDate })
      }
      onDone()
    } catch (err) { setError(err.message) }
    finally { setBusy(false) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>{enabling ? 'Habilitar' : 'Deshabilitar'} — {user.username}</h2>
        {error && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{error}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label>Anotación (opcional)</label>
            <input
              type="text"
              value={annotation}
              onChange={e => setAnnotation(e.target.value)}
              autoFocus
              placeholder={enabling ? 'Motivo de reactivación…' : 'Motivo de suspensión…'}
            />
          </div>
          {enabling && (
            <div className="form-group">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <input
                  type="checkbox"
                  id="with_expiry"
                  checked={withExpiry}
                  onChange={e => setWithExpiry(e.target.checked)}
                  style={{ width: 'auto', margin: 0 }}
                />
                <label htmlFor="with_expiry" style={{ margin: 0 }}>Poner fecha de caducidad</label>
              </div>
              {withExpiry && (
                <input
                  type="date"
                  value={expiryDate}
                  onChange={e => setExpiryDate(e.target.value)}
                  min={new Date().toISOString().slice(0, 10)}
                  required={withExpiry}
                />
              )}
            </div>
          )}
          <div className="modal-actions">
            <button type="button" className="btn-ghost" onClick={onClose}>Cancelar</button>
            <button
              type="submit"
              className={enabling ? 'btn-primary' : 'btn-danger'}
              disabled={busy}
            >
              {busy ? 'Guardando…' : (enabling ? 'Habilitar' : 'Deshabilitar')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
//  Modal: fecha de caducidad
// ---------------------------------------------------------------------------

function ExpiryModal({ user, onClose, onDone }) {
  const [expiryDate, setExpiryDate] = useState(
    user.expires_at ? user.expires_at.slice(0, 10) : ''
  )
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setError(null)
    try {
      await api.patch(`/admin/users/${user.id}/expiry`, {
        expires_at: expiryDate || null,
      })
      onDone()
    } catch (err) { setError(err.message) }
    finally { setBusy(false) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>Caducidad — {user.username}</h2>
        {error && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{error}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label>Fecha de caducidad (dejar vacío para sin límite)</label>
            <input
              type="date"
              value={expiryDate}
              onChange={e => setExpiryDate(e.target.value)}
              autoFocus
            />
          </div>
          <div className="modal-actions">
            <button type="button" className="btn-ghost" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn-primary" disabled={busy}>
              {busy ? 'Guardando…' : 'Guardar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
//  Modal: historial de estados
// ---------------------------------------------------------------------------

const STATUS_LABELS = {
  registered: { label: 'Alta',         color: 'var(--accent)' },
  enabled:    { label: 'Habilitado',   color: 'var(--green)' },
  disabled:   { label: 'Deshabilitado', color: 'var(--red)' },
  expired:    { label: 'Caducado',     color: 'var(--yellow)' },
}

function UserHistoryModal({ user, onClose }) {
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get(`/admin/users/${user.id}/history`)
      .then(setHistory)
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [user.id])

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 520 }} onClick={e => e.stopPropagation()}>
        <h2>Historial — {user.username}</h2>
        {loading ? (
          <div className="state-loading"><div className="spinner" /></div>
        ) : history.length === 0 ? (
          <div className="state-empty">Sin historial registrado.</div>
        ) : (
          <div style={{ maxHeight: 360, overflowY: 'auto' }}>
            {history.map(entry => {
              const meta = STATUS_LABELS[entry.status] ?? { label: entry.status, color: 'var(--text-muted)' }
              return (
                <div key={entry.id} style={{
                  display: 'flex', gap: 12, padding: '10px 0',
                  borderBottom: '1px solid var(--border)',
                }}>
                  <div style={{
                    width: 10, height: 10, borderRadius: '50%',
                    background: meta.color, flexShrink: 0, marginTop: 4,
                  }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                      <span style={{ fontWeight: 600, color: meta.color }}>{meta.label}</span>
                      <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                        {fmtDatetime(entry.created_at)}
                      </span>
                    </div>
                    {entry.actor_username && (
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        por {entry.actor_username}
                      </div>
                    )}
                    {entry.annotation && (
                      <div style={{ fontSize: '0.85rem', marginTop: 2 }}>{entry.annotation}</div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
        <div className="modal-actions">
          <button className="btn-ghost" onClick={onClose}>Cerrar</button>
        </div>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
//  Modal: cambiar contraseña de usuario
// ---------------------------------------------------------------------------

function ChangePasswordModal({ user, onClose, onDone }) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    if (password.length < 8) { setError('Mínimo 8 caracteres'); return }
    setBusy(true); setError(null)
    try {
      await api.patch(`/admin/users/${user.id}/password`, { password })
      onDone()
    } catch (err) { setError(err.message) }
    finally { setBusy(false) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>Cambiar contraseña — {user.username}</h2>
        {error && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{error}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label>Nueva contraseña</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoFocus
              required
              minLength={8}
            />
          </div>
          <div className="modal-actions">
            <button type="button" className="btn-ghost" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn-primary" disabled={busy}>
              {busy ? 'Guardando…' : 'Guardar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
//  Modal: crear usuario
// ---------------------------------------------------------------------------

function CreateUserModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ username: '', password: '', is_admin: false })
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  function field(name) {
    return {
      value: form[name],
      onChange: e => setForm(f => ({ ...f, [name]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })),
    }
  }

  async function submit(e) {
    e.preventDefault()
    if (form.username.trim().length < 3) { setError('Usuario: mínimo 3 caracteres'); return }
    if (form.password.length < 8) { setError('Contraseña: mínimo 8 caracteres'); return }
    setBusy(true); setError(null)
    try {
      await api.post('/admin/users', { ...form, username: form.username.trim() })
      onCreated()
    } catch (err) { setError(err.message) }
    finally { setBusy(false) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2>Nuevo usuario</h2>
        {error && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{error}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label>Nombre de usuario</label>
            <input type="text" autoFocus {...field('username')} required minLength={3} />
          </div>
          <div className="form-group">
            <label>Contraseña</label>
            <input type="password" {...field('password')} required minLength={8} />
          </div>
          <div className="form-group" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <input
              type="checkbox"
              id="is_admin"
              checked={form.is_admin}
              onChange={e => setForm(f => ({ ...f, is_admin: e.target.checked }))}
              style={{ width: 'auto', margin: 0 }}
            />
            <label htmlFor="is_admin" style={{ margin: 0 }}>Administrador</label>
          </div>
          <div className="modal-actions">
            <button type="button" className="btn-ghost" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn-primary" disabled={busy}>
              {busy ? 'Creando…' : 'Crear'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
//  Modal: splits / contrasplits de un valor
// ---------------------------------------------------------------------------

function SplitsModal({ security, onClose }) {
  const [splits, setSplits]   = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm]       = useState({ ex_date: '', ratio_num: 2, ratio_den: 1, notes: '' })
  const [busy, setBusy]       = useState(false)
  const [err, setErr]         = useState(null)

  async function load() {
    setLoading(true)
    try { setSplits(await api.get(`/admin/securities/${security.id}/splits`)) }
    catch (e) { setErr(e.message) }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [security.id])

  async function submit(e) {
    e.preventDefault()
    if (!form.ex_date) { setErr('La fecha es obligatoria'); return }
    if (Number(form.ratio_num) < 1 || Number(form.ratio_den) < 1) {
      setErr('Los ratios deben ser >= 1'); return
    }
    setBusy(true); setErr(null)
    try {
      await api.post(`/admin/securities/${security.id}/splits`, {
        ex_date: form.ex_date,
        ratio_num: Number(form.ratio_num),
        ratio_den: Number(form.ratio_den),
        notes: form.notes || null,
      })
      setForm({ ex_date: '', ratio_num: 2, ratio_den: 1, notes: '' })
      await load()
    } catch (e) { setErr(e.message) }
    finally { setBusy(false) }
  }

  async function del(id) {
    if (!confirm('¿Eliminar este split?')) return
    setErr(null)
    try { await api.delete(`/admin/splits/${id}`); await load() }
    catch (e) { setErr(e.message) }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 560 }} onClick={e => e.stopPropagation()}>
        <h2>Splits — {security.yahoo_ticker}</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: 16 }}>
          Los splits normalizan automáticamente las transacciones anteriores a la fecha efectiva
          para todos los usuarios que posean este valor.
        </p>

        {err && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{err}</div>}

        {/* Formulario de nuevo split */}
        <form onSubmit={submit} style={{ marginBottom: 20 }}>
          <div className="card-row" style={{ alignItems: 'flex-end', gap: 8 }}>
            <div className="form-group" style={{ flex: '0 0 130px', marginBottom: 0 }}>
              <label>Fecha efectiva</label>
              <input
                type="date"
                value={form.ex_date}
                onChange={e => setForm(f => ({ ...f, ex_date: e.target.value }))}
                required
              />
            </div>
            <div className="form-group" style={{ flex: '0 0 70px', marginBottom: 0 }}>
              <label>Nuevas</label>
              <input
                type="number" min={1} style={{ width: '100%' }}
                value={form.ratio_num}
                onChange={e => setForm(f => ({ ...f, ratio_num: e.target.value }))}
                required
              />
            </div>
            <span style={{ alignSelf: 'center', color: 'var(--text-muted)', fontSize: '1.2rem', paddingBottom: 4 }}>:</span>
            <div className="form-group" style={{ flex: '0 0 70px', marginBottom: 0 }}>
              <label>Antiguas</label>
              <input
                type="number" min={1} style={{ width: '100%' }}
                value={form.ratio_den}
                onChange={e => setForm(f => ({ ...f, ratio_den: e.target.value }))}
                required
              />
            </div>
            <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
              <label>Notas</label>
              <input
                type="text"
                value={form.notes}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Opcional"
              />
            </div>
            <button type="submit" className="btn-primary btn-sm" disabled={busy} style={{ marginBottom: 0 }}>
              {busy ? '…' : '+ Añadir'}
            </button>
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 4 }}>
            Ejemplo: split 2:1 → Nuevas=2, Antiguas=1 · Contrasplit 1:2 → Nuevas=1, Antiguas=2
          </div>
        </form>

        {/* Lista de splits */}
        {loading ? (
          <div className="state-loading"><div className="spinner" /></div>
        ) : splits.length === 0 ? (
          <div className="state-empty">No hay splits registrados para este valor.</div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Fecha efectiva</th>
                  <th>Ratio</th>
                  <th>Notas</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {splits.map(s => (
                  <tr key={s.id}>
                    <td>{s.ex_date}</td>
                    <td className="num">
                      <strong>{s.ratio_num}</strong>:{s.ratio_den}
                      <span style={{ marginLeft: 6, color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                        ({s.ratio_num > s.ratio_den ? 'split' : 'contrasplit'})
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{s.notes ?? '—'}</td>
                    <td>
                      <button className="btn-danger btn-sm" onClick={() => del(s.id)}>✕</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="modal-actions" style={{ marginTop: 16 }}>
          <button className="btn-ghost" onClick={onClose}>Cerrar</button>
        </div>
      </div>
    </div>
  )
}


// ---------------------------------------------------------------------------
//  Configuración del sistema
// ---------------------------------------------------------------------------

function ConfigSection() {
  const { setAppName } = useAppConfig()
  const [interval, setInterval]     = useState(null)
  const [inputVal, setInputVal]     = useState(5)
  const [appNameVal, setAppNameVal] = useState('')
  const [busy, setBusy]             = useState(false)
  const [nameBusy, setNameBusy]     = useState(false)
  const [refreshBusy, setRefreshBusy] = useState(false)
  const [msg, setMsg]               = useState(null)
  const [err, setErr]               = useState(null)

  useEffect(() => {
    api.get('/admin/config').then(d => {
      setInterval(d.snapshot_interval_minutes)
      setInputVal(d.snapshot_interval_minutes)
      setAppNameVal(d.app_name ?? 'FJS Finanzas')
    }).catch(() => {})
  }, [])

  async function saveInterval(e) {
    e.preventDefault()
    setBusy(true); setMsg(null); setErr(null)
    try {
      const d = await api.patch('/admin/config/snapshot-interval', { minutes: Number(inputVal) })
      setInterval(d.snapshot_interval_minutes)
      setMsg('Intervalo actualizado')
    } catch (e) { setErr(e.message) }
    finally { setBusy(false) }
  }

  async function saveAppName(e) {
    e.preventDefault()
    setNameBusy(true); setMsg(null); setErr(null)
    try {
      const d = await api.patch('/admin/config/app-name', { app_name: appNameVal })
      setAppName(d.app_name)
      setMsg('Nombre de la aplicación actualizado')
    } catch (e) { setErr(e.message) }
    finally { setNameBusy(false) }
  }

  async function refreshAll() {
    setRefreshBusy(true); setMsg(null); setErr(null)
    try {
      const d = await api.post('/markets/refresh-all')
      setMsg(d.detail)
    } catch (e) { setErr(e.message) }
    finally { setRefreshBusy(false) }
  }

  return (
    <div className="card" style={{ marginTop: 24 }}>
      <h2>Configuración del sistema</h2>
      {err && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{err}</div>}
      {msg && <div style={{ color: 'var(--green)', padding: 8, marginBottom: 12 }}>{msg}</div>}

      {/* Nombre de la aplicación */}
      <form onSubmit={saveAppName} style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap', marginBottom: 20 }}>
        <div className="form-group" style={{ flex: '1 1 200px', marginBottom: 0 }}>
          <label>Nombre de la aplicación</label>
          <input
            type="text"
            value={appNameVal}
            onChange={e => setAppNameVal(e.target.value)}
            maxLength={100}
            placeholder="FJS Finanzas"
          />
        </div>
        <button type="submit" className="btn-primary btn-sm" disabled={nameBusy || !appNameVal.trim()}>
          {nameBusy ? 'Guardando…' : 'Aplicar nombre'}
        </button>
      </form>

      {/* Intervalo de snapshots */}
      <form onSubmit={saveInterval} style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap', marginBottom: 16 }}>
        <div className="form-group" style={{ flex: '0 0 auto', marginBottom: 0 }}>
          <label>Intervalo actualización precios (min)</label>
          <input
            type="number" min={5} max={60}
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            style={{ width: 80 }}
          />
        </div>
        <button type="submit" className="btn-primary btn-sm" disabled={busy || interval === null}>
          {busy ? 'Guardando…' : 'Guardar'}
        </button>
        {interval !== null && (
          <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem', alignSelf: 'center' }}>
            Actual: {interval} min
          </span>
        )}
      </form>

      <button className="btn-ghost btn-sm" disabled={refreshBusy} onClick={refreshAll}>
        {refreshBusy ? 'Actualizando…' : '↺ Actualizar todos los valores ahora'}
      </button>
    </div>
  )
}


// ---------------------------------------------------------------------------
//  Gestión de mercados (catálogo dinámico)
// ---------------------------------------------------------------------------

const EMPTY_MARKET = { code: '', name: '', index_ticker: '', currency: 'EUR', fiscal_window_days: 60 }

function MarketsSection() {
  const [markets, setMarkets]   = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing]   = useState(null)
  const [form, setForm]         = useState(EMPTY_MARKET)
  const [busy, setBusy]         = useState(false)
  const [err, setErr]           = useState(null)
  const [msg, setMsg]           = useState(null)

  async function load() { setMarkets(await api.get('/admin/markets')) }
  useEffect(() => { load() }, [])

  function field(name) {
    return {
      value: form[name],
      onChange: e => setForm(f => ({ ...f, [name]: e.target.value })),
    }
  }

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setErr(null); setMsg(null)
    try {
      const body = { ...form, fiscal_window_days: Number(form.fiscal_window_days) }
      if (!body.index_ticker) delete body.index_ticker
      if (editing) {
        await api.patch(`/admin/markets/${editing.code}`, {
          name: body.name,
          index_ticker: body.index_ticker,
          currency: body.currency,
          fiscal_window_days: body.fiscal_window_days,
        })
        setMsg('Mercado actualizado')
      } else {
        await api.post('/admin/markets', body)
        setMsg('Mercado creado')
      }
      setShowForm(false); setEditing(null); setForm(EMPTY_MARKET)
      await load()
    } catch (e) { setErr(e.message) }
    finally { setBusy(false) }
  }

  async function del(code) {
    if (!confirm(`¿Eliminar el mercado "${code}"?`)) return
    setErr(null); setMsg(null)
    try {
      await api.delete(`/admin/markets/${code}`)
      await load()
    } catch (e) { setErr(e.message) }
  }

  function startEdit(m) {
    setEditing(m)
    setForm({ code: m.code, name: m.name, index_ticker: m.index_ticker ?? '', currency: m.currency, fiscal_window_days: m.fiscal_window_days })
    setShowForm(true)
    setErr(null); setMsg(null)
  }

  return (
    <div className="card" style={{ marginTop: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Mercados</h2>
        <button className="btn-primary btn-sm" onClick={() => {
          setEditing(null); setForm(EMPTY_MARKET); setShowForm(s => !s); setErr(null); setMsg(null)
        }}>
          {showForm && !editing ? 'Cancelar' : '+ Nuevo mercado'}
        </button>
      </div>

      {err && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{err}</div>}
      {msg && <div style={{ color: 'var(--green)', padding: 8, marginBottom: 12 }}>{msg}</div>}

      {showForm && (
        <div className="card" style={{ marginBottom: 16, background: 'var(--bg-input)' }}>
          <h3 style={{ marginTop: 0 }}>{editing ? 'Editar mercado' : 'Nuevo mercado'}</h3>
          <form onSubmit={submit}>
            <div className="card-row">
              <div className="form-group" style={{ flex: 1 }}>
                <label>Código *</label>
                <input type="text" {...field('code')} required disabled={!!editing} placeholder="ibex35" />
              </div>
              <div className="form-group" style={{ flex: 2 }}>
                <label>Nombre *</label>
                <input type="text" {...field('name')} required />
              </div>
            </div>
            <div className="card-row">
              <div className="form-group" style={{ flex: 1 }}>
                <label>Ticker índice</label>
                <input type="text" {...field('index_ticker')} placeholder="^IBEX" />
              </div>
              <div className="form-group" style={{ flex: 1 }}>
                <label>Divisa</label>
                <select {...field('currency')}>
                  <option value="EUR">EUR</option>
                  <option value="USD">USD</option>
                </select>
              </div>
              <div className="form-group" style={{ flex: 1 }}>
                <label>Ventana fiscal (días)</label>
                <input type="number" min={1} {...field('fiscal_window_days')} style={{ width: 80 }} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button type="button" className="btn-ghost btn-sm" onClick={() => { setShowForm(false); setEditing(null) }}>Cancelar</button>
              <button type="submit" className="btn-primary btn-sm" disabled={busy}>{busy ? 'Guardando…' : 'Guardar'}</button>
            </div>
          </form>
        </div>
      )}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Código</th>
              <th>Nombre</th>
              <th>Ticker índice</th>
              <th>Divisa</th>
              <th>Ventana fiscal</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {markets.map(m => (
              <tr key={m.code}>
                <td><code style={{ fontSize: '0.85rem' }}>{m.code}</code></td>
                <td>{m.name}</td>
                <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{m.index_ticker ?? '—'}</td>
                <td>{m.currency}</td>
                <td className="num">{m.fiscal_window_days}d</td>
                <td>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                    <button className="btn-ghost btn-sm" onClick={() => startEdit(m)}>✎</button>
                    <button className="btn-danger btn-sm" onClick={() => del(m.code)}>✕</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}


// ---------------------------------------------------------------------------
//  Catálogo de valores (securities CRUD)
// ---------------------------------------------------------------------------

const EMPTY_SEC = { name: '', isin: '', yahoo_ticker: '', google_ticker: '', market: '', currency: 'EUR' }
const CURRENCIES = ['EUR', 'USD']

function SecuritiesSection() {
  const [markets, setMarkets]     = useState([])
  const [securities, setSecs]     = useState([])
  const [showForm, setShowForm]   = useState(false)
  const [editing, setEditing]     = useState(null)
  const [form, setForm]           = useState(EMPTY_SEC)
  const [busy, setBusy]           = useState(false)
  const [err, setErr]             = useState(null)
  const [msg, setMsg]             = useState(null)
  const [splitsFor, setSplitsFor] = useState(null)   // security para SplitsModal

  async function load() {
    const [mks, secs] = await Promise.all([api.get('/markets/list'), api.get('/securities')])
    setMarkets(mks)
    setSecs(secs)
    if (!form.market && mks.length) setForm(f => ({ ...f, market: mks[0].code }))
  }
  useEffect(() => { load() }, [])

  function field(name) {
    return { value: form[name], onChange: e => setForm(f => ({ ...f, [name]: e.target.value })) }
  }

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setErr(null); setMsg(null)
    try {
      const body = { ...form }
      if (!body.isin) delete body.isin
      if (!body.google_ticker) delete body.google_ticker
      if (editing) {
        await api.patch(`/securities/${editing.id}`, body)
        setMsg('Valor actualizado')
      } else {
        await api.post('/securities', body)
        setMsg('Valor añadido')
      }
      setShowForm(false); setEditing(null)
      setForm(f => ({ ...EMPTY_SEC, market: markets[0]?.code ?? '' }))
      await load()
    } catch (e) { setErr(e.message) }
    finally { setBusy(false) }
  }

  async function del(id, ticker) {
    if (!confirm(`¿Eliminar ${ticker}?`)) return
    setErr(null); setMsg(null)
    try { await api.delete(`/securities/${id}`); await load() }
    catch (e) { setErr(e.message) }
  }

  function startEdit(s) {
    setEditing(s)
    setForm({ name: s.name, isin: s.isin ?? '', yahoo_ticker: s.yahoo_ticker, google_ticker: s.google_ticker ?? '', market: s.market, currency: s.currency })
    setShowForm(true); setErr(null); setMsg(null)
  }

  return (
    <div className="card" style={{ marginTop: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0 }}>Catálogo de valores</h2>
        <button className="btn-primary btn-sm" onClick={() => {
          setEditing(null)
          setForm({ ...EMPTY_SEC, market: markets[0]?.code ?? '' })
          setShowForm(s => !s); setErr(null); setMsg(null)
        }}>
          {showForm && !editing ? 'Cancelar' : '+ Nuevo valor'}
        </button>
      </div>

      {err && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{err}</div>}
      {msg && <div style={{ color: 'var(--green)', padding: 8, marginBottom: 12 }}>{msg}</div>}

      {showForm && (
        <div className="card" style={{ marginBottom: 16, background: 'var(--bg-input)' }}>
          <h3 style={{ marginTop: 0 }}>{editing ? 'Editar valor' : 'Nuevo valor'}</h3>
          <form onSubmit={submit}>
            <div className="card-row">
              <div className="form-group" style={{ flex: 2 }}>
                <label>Nombre *</label>
                <input type="text" {...field('name')} required />
              </div>
              <div className="form-group" style={{ flex: 1 }}>
                <label>ISIN</label>
                <input type="text" {...field('isin')} placeholder="ES0144580Y14" />
              </div>
            </div>
            <div className="card-row">
              <div className="form-group" style={{ flex: 1 }}>
                <label>Yahoo Ticker *</label>
                <input type="text" {...field('yahoo_ticker')} required placeholder="SAN.MC" />
              </div>
              <div className="form-group" style={{ flex: 1 }}>
                <label>Google Ticker</label>
                <input type="text" {...field('google_ticker')} />
              </div>
            </div>
            <div className="card-row">
              <div className="form-group" style={{ flex: 1 }}>
                <label>Mercado *</label>
                <select {...field('market')}>
                  {markets.map(m => <option key={m.code} value={m.code}>{m.name}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ flex: 1 }}>
                <label>Divisa *</label>
                <select {...field('currency')}>
                  {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button type="button" className="btn-ghost btn-sm" onClick={() => { setShowForm(false); setEditing(null) }}>Cancelar</button>
              <button type="submit" className="btn-primary btn-sm" disabled={busy}>{busy ? 'Guardando…' : 'Guardar'}</button>
            </div>
          </form>
        </div>
      )}

      {securities.length === 0 ? (
        <div className="state-empty">No hay valores en el catálogo.</div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Ticker</th>
                <th>Nombre</th>
                <th>ISIN</th>
                <th>Mercado</th>
                <th>Divisa</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {securities.map(s => (
                <tr key={s.id}>
                  <td className="ticker">{s.yahoo_ticker}</td>
                  <td>{s.name}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{s.isin ?? '—'}</td>
                  <td><span className="badge badge-market">{s.market}</span></td>
                  <td>{s.currency}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button className="btn-ghost btn-sm" onClick={() => setSplitsFor(s)} title="Gestionar splits">
                        ÷ Splits
                      </button>
                      <button className="btn-ghost btn-sm" onClick={() => startEdit(s)}>✎</button>
                      <button className="btn-danger btn-sm" onClick={() => del(s.id, s.yahoo_ticker)}>✕</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {splitsFor && (
        <SplitsModal
          security={splitsFor}
          onClose={() => setSplitsFor(null)}
        />
      )}
    </div>
  )
}


// ---------------------------------------------------------------------------
//  Panel principal
// ---------------------------------------------------------------------------

export default function AdminPanel() {
  const { user: me, logout } = useAuth()
  const { appName } = useAppConfig()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [opError, setOpError] = useState(null)
  const [showCreate, setShowCreate] = useState(false)
  const [changingPw, setChangingPw] = useState(null)
  const [statusModal, setStatusModal] = useState(null)   // usuario para enable/disable
  const [expiryModal, setExpiryModal] = useState(null)   // usuario para fijar caducidad
  const [historyModal, setHistoryModal] = useState(null) // usuario para ver historial

  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' })

  // Backup admin
  const adminFileRef                        = useRef(null)
  const [adminImporting, setAdminImporting] = useState(false)
  const [adminBackupMsg, setAdminBackupMsg] = useState(null)
  const [adminBackupErr, setAdminBackupErr] = useState(null)
  const [pwBusy, setPwBusy] = useState(false)
  const [pwError, setPwError] = useState(null)
  const [pwOk, setPwOk] = useState(false)

  async function changeOwnPassword(e) {
    e.preventDefault()
    setPwError(null); setPwOk(false)
    if (pwForm.newPw.length < 8) { setPwError('Mínimo 8 caracteres'); return }
    if (pwForm.newPw !== pwForm.confirm) { setPwError('Las contraseñas no coinciden'); return }
    setPwBusy(true)
    try {
      await api.patch('/auth/password', { current_password: pwForm.current, new_password: pwForm.newPw })
      setPwForm({ current: '', newPw: '', confirm: '' })
      setPwOk(true)
    } catch (err) { setPwError(err.message) }
    finally { setPwBusy(false) }
  }

  async function exportAdminBackup() {
    setAdminBackupErr(null)
    const res = await fetch('/api/admin/backup/export', { credentials: 'include' })
    if (!res.ok) { setAdminBackupErr('Error al exportar'); return }
    const blob = await res.blob()
    const cd = res.headers.get('Content-Disposition') ?? ''
    const match = cd.match(/filename="([^"]+)"/)
    const filename = match ? match[1] : 'finanzas_admin_backup.json'
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = filename; a.click()
    URL.revokeObjectURL(url)
  }

  async function importAdminBackup(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setAdminImporting(true); setAdminBackupErr(null); setAdminBackupMsg(null)
    try {
      const text = await file.text()
      const data = JSON.parse(text)
      const r = await api.post('/admin/backup/import', data)
      setAdminBackupMsg(
        `Importado: ${r.users_created} usuarios nuevos, ` +
        `${r.securities_created} valores nuevos (${r.securities_updated} actualizados), ` +
        `${r.positions_found} posiciones, ` +
        `${r.transactions_added} transacciones, ` +
        `${r.dividends_added} dividendos, ` +
        `${r.favorites_added} favoritos.` +
        (r.errors?.length ? ` Avisos: ${r.errors.join('; ')}` : '')
      )
      loadUsers()
    } catch (err) {
      setAdminBackupErr(err.message ?? 'Error al importar')
    } finally {
      setAdminImporting(false)
      e.target.value = ''
    }
  }

  async function loadUsers() {
    setLoading(true)
    try {
      setUsers(await api.get('/admin/users'))
    } catch (err) { setError(err.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { loadUsers() }, [])

  async function deleteUser(u) {
    if (!confirm(`¿Eliminar al usuario "${u.username}"? Esta acción no se puede deshacer.`)) return
    setOpError(null)
    try {
      await api.delete(`/admin/users/${u.id}`)
      setUsers(us => us.filter(x => x.id !== u.id))
    } catch (err) { setOpError(err.message) }
  }

  async function toggleRole(u) {
    const newRole = !u.is_admin
    const label = newRole ? 'administrador' : 'usuario normal'
    if (!confirm(`¿Cambiar "${u.username}" a ${label}?`)) return
    setOpError(null)
    try {
      const updated = await api.patch(`/admin/users/${u.id}/role`, { is_admin: newRole })
      setUsers(us => us.map(x => x.id === u.id ? updated : x))
    } catch (err) { setOpError(err.message) }
  }

  if (loading) return <div className="state-loading" style={{ minHeight: '100vh' }}><div className="spinner" /></div>
  if (error)   return <div className="state-error">{error}</div>

  return (
    <div style={{ maxWidth: 820, margin: '0 auto', padding: '24px 16px' }}>
      {/* Cabecera */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: '1.4rem' }}>Administración</h1>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{appName} · {me?.username}</span>
        </div>
        <button className="btn-ghost btn-sm" onClick={logout}>Salir</button>
      </div>

      {opError && (
        <div
          className="state-error"
          style={{ marginBottom: 16, cursor: 'pointer', display: 'flex', justifyContent: 'space-between' }}
          onClick={() => setOpError(null)}
        >
          <span>{opError}</span>
          <span>✕</span>
        </div>
      )}

      {/* Tabla de usuarios */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ margin: 0 }}>Usuarios ({users.length})</h2>
          <button className="btn-primary btn-sm" onClick={() => setShowCreate(true)}>+ Nuevo usuario</button>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Usuario</th>
                <th>Rol</th>
                <th>Estado</th>
                <th>Caduca</th>
                <th>Creado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <span style={{ fontWeight: u.id === me?.id ? 600 : 400 }}>{u.username}</span>
                    {u.id === me?.id && <span style={{ marginLeft: 6, fontSize: '0.75rem', color: 'var(--text-muted)' }}>(tú)</span>}
                  </td>
                  <td>
                    <span
                      className="badge"
                      style={{
                        background: u.is_admin ? 'var(--accent)' : 'var(--bg-input)',
                        color: u.is_admin ? '#fff' : 'var(--text-muted)',
                      }}
                    >
                      {u.is_admin ? 'Admin' : 'Usuario'}
                    </span>
                  </td>
                  <td><StatusBadge enabled={u.is_enabled} /></td>
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    {u.expires_at ? fmt(u.expires_at) : '—'}
                  </td>
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{fmt(u.created_at)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                      <button
                        className="btn-ghost btn-sm"
                        onClick={() => setChangingPw(u)}
                      >
                        Contraseña
                      </button>
                      <button
                        className="btn-ghost btn-sm"
                        onClick={() => setHistoryModal(u)}
                        title="Ver historial de estados"
                      >
                        Historial
                      </button>
                      {u.id !== me?.id && (
                        <>
                          <button
                            className={u.is_enabled ? 'btn-danger btn-sm' : 'btn-primary btn-sm'}
                            onClick={() => setStatusModal(u)}
                            title={u.is_enabled ? 'Deshabilitar usuario' : 'Habilitar usuario'}
                          >
                            {u.is_enabled ? 'Deshabilitar' : 'Habilitar'}
                          </button>
                          <button
                            className="btn-ghost btn-sm"
                            onClick={() => setExpiryModal(u)}
                            title="Fecha de caducidad"
                          >
                            Caducidad
                          </button>
                          <button
                            className="btn-ghost btn-sm"
                            onClick={() => toggleRole(u)}
                            title={u.is_admin ? 'Quitar admin' : 'Hacer admin'}
                          >
                            {u.is_admin ? '↓ Usuario' : '↑ Admin'}
                          </button>
                          <button
                            className="btn-danger btn-sm"
                            onClick={() => deleteUser(u)}
                          >
                            Eliminar
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cambiar mi contraseña */}
      <div className="card" style={{ marginTop: 24 }}>
        <h2>Cambiar mi contraseña</h2>
        {pwError && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{pwError}</div>}
        {pwOk    && <div style={{ color: 'var(--green)', padding: 8, marginBottom: 12 }}>Contraseña actualizada correctamente.</div>}
        <form onSubmit={changeOwnPassword}>
          <div className="form-group">
            <label>Contraseña actual</label>
            <input
              type="password"
              value={pwForm.current}
              onChange={e => setPwForm(f => ({ ...f, current: e.target.value }))}
              required
            />
          </div>
          <div className="form-group">
            <label>Nueva contraseña</label>
            <input
              type="password"
              value={pwForm.newPw}
              onChange={e => setPwForm(f => ({ ...f, newPw: e.target.value }))}
              required
              minLength={8}
            />
          </div>
          <div className="form-group">
            <label>Repetir nueva contraseña</label>
            <input
              type="password"
              value={pwForm.confirm}
              onChange={e => setPwForm(f => ({ ...f, confirm: e.target.value }))}
              required
            />
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" className="btn-primary btn-sm" disabled={pwBusy}>
              {pwBusy ? 'Guardando…' : 'Cambiar contraseña'}
            </button>
          </div>
        </form>
      </div>

      {/* Backup completo del sistema */}
      <div className="card" style={{ marginTop: 24 }}>
        <h2>Backup completo del sistema</h2>
        <p style={{ color: 'var(--text-muted)', marginBottom: 16, fontSize: '0.9rem' }}>
          Exporta todos los usuarios, el catálogo de valores y todas las carteras a un JSON.
          La importación es idempotente: crea lo que no existe y omite lo que ya está.
        </p>
        {adminBackupErr && <div className="state-error" style={{ padding: 8, marginBottom: 12 }}>{adminBackupErr}</div>}
        {adminBackupMsg && <div style={{ color: 'var(--green)', padding: 8, marginBottom: 12, fontSize: '0.85rem' }}>{adminBackupMsg}</div>}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="btn-primary btn-sm" onClick={exportAdminBackup}>
            ↓ Exportar backup completo
          </button>
          <button
            className="btn-ghost btn-sm"
            disabled={adminImporting}
            onClick={() => adminFileRef.current?.click()}
          >
            {adminImporting ? 'Importando…' : '↑ Importar backup'}
          </button>
          <input
            ref={adminFileRef}
            type="file"
            accept=".json,application/json"
            style={{ display: 'none' }}
            onChange={importAdminBackup}
          />
        </div>
      </div>

      <ConfigSection />
      <MarketsSection />
      <SecuritiesSection />

      {/* Modales */}
      {showCreate && (
        <CreateUserModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); loadUsers() }}
        />
      )}
      {changingPw && (
        <ChangePasswordModal
          user={changingPw}
          onClose={() => setChangingPw(null)}
          onDone={() => setChangingPw(null)}
        />
      )}
      {statusModal && (
        <UserStatusModal
          user={statusModal}
          onClose={() => setStatusModal(null)}
          onDone={() => { setStatusModal(null); loadUsers() }}
        />
      )}
      {expiryModal && (
        <ExpiryModal
          user={expiryModal}
          onClose={() => setExpiryModal(null)}
          onDone={() => { setExpiryModal(null); loadUsers() }}
        />
      )}
      {historyModal && (
        <UserHistoryModal
          user={historyModal}
          onClose={() => setHistoryModal(null)}
        />
      )}
    </div>
  )
}
